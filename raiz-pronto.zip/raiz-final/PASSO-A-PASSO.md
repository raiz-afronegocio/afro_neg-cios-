# Raiz no ar — passo a passo

Ao final você terá o site num link público, que qualquer pessoa abre sem conta no Claude, sem cair e sem perder os cadastros.

**Tempo:** uns 20 minutos. **Custo:** cerca de US$ 5 por mês no Railway, mais um domínio opcional (cerca de R$ 40 por ano).

## Arquivos desta pasta

| Arquivo | O que é |
|---|---|
| `server.js` | O site inteiro: servidor, banco de dados e páginas |
| `package.json` | Diz ao Railway que é um site Node.js |
| `railway.json` | Configuração do Railway: como iniciar e como checar se está no ar |
| `.gitignore` | Impede que os dados dos usuários vão para o GitHub |
| `PASSO-A-PASSO.md` | Este guia |

---

## Parte 1 — Colocar os arquivos no GitHub

1. Entre em **https://github.com** e crie uma conta, se ainda não tiver.
2. No canto superior direito, clique em **+** → **New repository**.
3. Em **Repository name**, escreva `raiz`.
4. Escolha **Private**, para ninguém ver o código.
5. Clique em **Create repository**.
6. Na página que abrir, clique no link **uploading an existing file**.
7. Arraste para a página **todos os arquivos desta pasta**: `server.js`, `package.json`, `railway.json` e `.gitignore`.
   - Se o `.gitignore` não aparecer na pasta, não tem problema. Ele é opcional.
8. Clique no botão verde **Commit changes**.

✅ Os arquivos devem aparecer listados no repositório.

---

## Parte 2 — Publicar no Railway

1. Entre em **https://railway.app** e clique em **Login** → **Login with GitHub**. Autorize o acesso.
2. Clique em **New Project** → **Deploy from GitHub repo**.
   - Se pedir, clique em **Configure GitHub App** e libere o repositório `raiz`.
3. Escolha o repositório **raiz**. O Railway começa a publicar sozinho.
4. Espere aparecer **Success** ou **Active**, de 1 a 3 minutos.

✅ O serviço `raiz` aparece no painel com uma bolinha verde.

---

## Parte 3 — Guardar os cadastros (não pule esta parte)

Sem isso, o Railway apaga todas as contas e anúncios toda vez que o servidor reinicia.

1. No painel do projeto, clique em **+ Create** (ou clique com o botão direito numa área vazia) → **Volume**.
2. Escolha o serviço **raiz** para ligar o volume.
3. Em **Mount path**, escreva exatamente: `/data`
4. Clique no serviço **raiz** → aba **Variables** → **New Variable**.
   - **Nome:** `DATA_FILE`
   - **Valor:** `/data/dados.json`
5. Clique em **Add** e depois em **Deploy**, se o botão aparecer. O Railway reinicia o site.

---

## Parte 4 — Gerar o link público

1. Clique no serviço **raiz** → aba **Settings** → seção **Networking**.
2. Clique em **Generate Domain**.
3. Aparece um link como `raiz-production-xxxx.up.railway.app`. Esse é o endereço do seu site.

✅ **Confira se ficou certo:** abra `SEU-LINK/api/saude`. Deve aparecer algo como:

```
{"ok":true,"usuarios":0,"anuncios":0,"dadosPersistentes":true}
```

Se aparecer `"dadosPersistentes":false`, refaça a Parte 3.

---

## Parte 5 — Não deixar o site cair

1. No Railway, clique na sua foto (canto superior direito) → **Account Settings** → **Plans**.
2. Escolha **Hobby** (cerca de US$ 5 por mês) e cadastre o cartão.

O teste grátis acaba quando os créditos terminam, e aí o site sai do ar. Com o Hobby ele fica ligado o tempo todo.

---

## Parte 6 — Domínio próprio (opcional)

Assim o link fica, por exemplo, `www.raizprodutores.com.br`, sem "railway" no endereço.

1. Registre o domínio em **https://registro.br**.
2. No Railway: serviço **raiz** → **Settings** → **Networking** → **Custom Domain**. Digite `www.seudominio.com.br`.
3. O Railway mostra um registro **CNAME**, com um nome e um valor. Copie os dois.
4. No registro.br: **Painel** → clique no domínio → **Editar zona** (ou **DNS**) → **Nova entrada**:
   - **Tipo:** `CNAME`
   - **Nome:** `www`
   - **Dados:** o valor que o Railway mostrou
5. Salve. Em algumas horas, às vezes até 24, o site abre no seu domínio, com cadeado (HTTPS) automático.

---

## Para atualizar o site depois

1. No GitHub, abra o repositório `raiz` → **Add file** → **Upload files**.
2. Arraste o `server.js` novo e clique em **Commit changes**.
3. O Railway publica sozinho em 1 ou 2 minutos. Os cadastros continuam, porque ficam no volume.

## Fazer backup dos dados

O site guarda tudo em `/data/dados.json` e faz cópias automáticas a cada hora (`dados.json.backup1`, `2` e `3`) no mesmo volume. Para ter uma cópia no seu computador, use no Railway: serviço **raiz** → **Volume** → **Backups**, ou peça para eu montar uma página de exportação.

## Se der algum problema

| O que aconteceu | O que fazer |
|---|---|
| Deploy com erro (bolinha vermelha) | Clique em **View logs**, copie o que aparece em vermelho e me mande |
| `"dadosPersistentes":false` | Refaça a Parte 3: o volume precisa estar em `/data` e a variável `DATA_FILE` = `/data/dados.json` |
| Contas sumiram depois de atualizar | O volume não estava ligado. Refaça a Parte 3 |
| Site fora do ar depois de alguns dias | O teste grátis acabou. Faça a Parte 5 |
| Domínio não abre | Espere até 24 horas e confira se o CNAME está igual ao do Railway |
