# Raiz — classificados de pequenos produtores

Site completo com contas (nome, idade 18+, Gmail e senha), anúncios com foto e estoque, compras que descontam 1 do estoque, pedidos com status, favoritos, avaliações e recomendações, chat geral e chat privado com o vendedor em tempo real.

Funciona para qualquer pessoa que abrir o link. Não precisa de conta Claude nem de Firebase.

## O que tem na pasta

- `server.js` — o servidor (contas, anúncios, pedidos, chat e banco de dados).
- `public/index.html` — o site.
- `package.json` e `package-lock.json` — o que o servidor precisa instalar, com as versões travadas.
- `iniciar-windows.bat` e `iniciar-mac.command` — abrem o site com dois cliques.
- `railway.json` — configuração pronta para o Railway.
- `render.yaml` — configuração pronta para o Render, já com disco para os dados.
- `Dockerfile` e `.dockerignore` — para rodar em qualquer servidor com Docker.
- `.env.example` — as variáveis de configuração explicadas.
- `.gitignore` — impede que o banco de dados e o `node_modules` vão para o GitHub.
- `dados.json` — o banco de dados. É criado sozinho na primeira vez que alguém se cadastra.

## Jeito mais fácil de abrir

1. Instale o **Node.js** (versão LTS) em https://nodejs.org.
2. Descompacte esta pasta.
3. Dê dois cliques em `iniciar-windows.bat` (Windows) ou em `iniciar-mac.command` (Mac). Na primeira vez ele instala o que precisa e abre o site no navegador.

No Mac, se aparecer um aviso de segurança, clique com o botão direito no arquivo e escolha **Abrir**.

## Rodar pelo terminal

1. Instale o **Node.js** (versão 18 ou mais nova) em https://nodejs.org. Escolha a versão "LTS".
2. Descompacte esta pasta.
3. Abra o terminal dentro da pasta:
   - **Windows:** abra a pasta, clique na barra de endereço, digite `cmd` e aperte Enter.
   - **Mac:** clique com o botão direito na pasta e escolha "Novo Terminal na Pasta".
4. Rode estes dois comandos, um de cada vez:

   ```
   npm install
   npm start
   ```

5. Abra no navegador: **http://localhost:3000**

Para parar o servidor, aperte `Ctrl + C` no terminal.

Outras pessoas na mesma rede Wi-Fi podem acessar pelo IP do seu computador, por exemplo `http://192.168.0.10:3000`.

## Colocar na internet

O site precisa de um serviço que rode Node.js. Uma opção simples é o **Railway** (https://railway.app):

1. Crie uma conta e envie esta pasta para um repositório no GitHub.
2. No Railway: **New Project → Deploy from GitHub repo** e escolha o repositório.
3. Para os dados não se perderem quando o servidor reiniciar, adicione um **Volume** montado em `/data` e crie a variável `DATA_FILE` com o valor `/data/dados.json`.
4. Em **Settings → Networking**, clique em **Generate Domain** para ganhar o link público.

O Render (https://render.com) também funciona: Build Command `npm install`, Start Command `npm start`. No plano grátis do Render os dados se perdem quando o servidor reinicia. Para guardar os dados lá, use um plano com disco e aponte `DATA_FILE` para ele.

## Configurações opcionais

| Variável    | Para que serve                            | Padrão                 |
|-------------|-------------------------------------------|------------------------|
| `PORT`      | Porta do servidor                         | `3000`                 |
| `DATA_FILE` | Onde o banco de dados é guardado          | `dados.json` na pasta  |

## Bom saber

- **Faça backup do `dados.json`** de vez em quando. Ele guarda todas as contas, anúncios e mensagens.
- As senhas são guardadas criptografadas (scrypt). Idade e Gmail só o próprio usuário vê. Para os outros aparece apenas o nome da conta.
- O chat privado só é entregue às duas pessoas da conversa.
- Não tem "esqueci minha senha", porque isso exigiria enviar e-mails. Se alguém esquecer, o dono do site pode apagar a conta dessa pessoa no `dados.json`.
- O site registra a compra e desconta o estoque, mas não processa pagamento. Pagamento e entrega são combinados pelo chat.
- O banco em arquivo JSON aguenta bem algumas centenas de usuários. Se o site crescer muito, o próximo passo é trocar por um banco de dados de verdade, como PostgreSQL.
