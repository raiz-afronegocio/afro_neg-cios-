#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d node_modules ]; then
  echo "Instalando pela primeira vez..."
  npm install
fi
(sleep 2 && open http://localhost:3000) &
npm start
